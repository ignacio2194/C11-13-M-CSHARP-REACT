import Form from "../../components/Form/Form";

const Login = () => {
  return (
    <div>
      <Form />
    </div>
  );
};
export default Login;

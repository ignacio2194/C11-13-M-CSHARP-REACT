import { Box } from "@mui/material"

const FooterSecondary = () => {
  return (
    <Box sx={{ width: "100%", height: "70px", backgroundColor: "primary.main", marginTop: "68px" }}></Box>
  )
}
export default FooterSecondary